import UIKit

class Dog
{
    var name:String
    var color:String
    var age:Int

    init(name: String, color:String,age: Int) {
        self.name = name
        self.age = age
        self.color = color
    }
}

class Person
{
    var name:String
    var identifier:String
    var age:Int
    var dogs:[Dog]

    init(name: String, identifier:String, age: Int, dogs:[Dog]) {
        self.name = name
        self.age = age
        self.identifier = identifier
        self.dogs = dogs
    }
}

func setData()
{
    let dog1 = Dog(name:"Dog1", color:"Black", age:5)
    let dog2 = Dog(name:"Dog2", color:"White", age:3)
    let dogs1 = [dog1,dog2]

    let dog3 = Dog(name:"Dog3", color:"Red", age:4)
    let dog4 = Dog(name:"Dog4", color:"Brown", age:2)
    let dogs2 = [dog3,dog4]

    let person1 = Person(name:"Jason", identifier:"303970921", age:35, dogs: dogs1)
    let person2 = Person(name:"Rafael", identifier:"303970922", age:34, dogs: dogs2)
    let person3 = Person(name:"Jose", identifier:"303970923", age:33, dogs: dogs1)

    let people = [person1,person2,person3]

    for (_, value) in people.enumerated()
    {
        print("Nombre : \(value.name)")
        print("Identificador : \(value.identifier)")
        print("Edad : \(value.age) anhos")
        print("Cantidad de perros : \(value.dogs.count) ")
        for (index1, value1) in value.dogs.enumerated()
        {
            print("   Perro \(index1 + 1)")
            print("         Nombre : \(value1.name)")
            print("         Color : \(value1.color)")
            print("         Edad : \(value1.age) anhos")
        }
    }
    
}

let result1 = setData

func numerosPrimos (numero: Int) -> [Int]?
{
    var arrayPrimos = [0]
    if (numero > 0)
    {
        for count in 1...numero {
            if (count % 2 != 0)
            {
                arrayPrimos.append(count)
            }
        }
    }

    return arrayPrimos
}

let result2 = numerosPrimos(numero:10)

func ordenarArray (array1: [Int], array2: [Int]) -> [Int]?
{
    var arrayOrdenado = [Int]()
    var array = [Int]()
    if (array1.count > 0 &&  array2.count > 0)
    {
        for count in 0...array1.count - 1 {
            array.append(array1[count])
        }
        
        for count in 0...array2.count - 1 {
            array.append(array2[count])
        }
        
        arrayOrdenado = array.sorted(by: ({$0 < $1}))
    }
    
    return arrayOrdenado
}

let result3 = ordenarArray(array1:[14,12,4,4,-20,89],array2:[1,3,5,90,-1])













